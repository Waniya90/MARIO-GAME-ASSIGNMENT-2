/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;

/**
 *
 * @author newit
 */

public class Player {
    // Player position
    private int x, y;
    private int dx, dy;
    private final int PLAYER_WIDTH = 50;
    private final int PLAYER_HEIGHT = 50;

    // Jumping
    private boolean jumping = false;
    private boolean falling = false;
    private int jumpSpeed = 15;
    private int fallSpeed = 10;
    private int gravity = 1;

    // Movement flags
    private boolean left = false;
    private boolean right = false;

    // Constructor
    public Player(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Update player position
    public void update() {
        // Horizontal movement
        if (left) {
            dx = -5;
        } else if (right) {
            dx = 5;
        } else {
            dx = 0;
        }

        // Jumping mechanics
        if (jumping) {
            dy -= jumpSpeed;
            jumping = false;
            falling = true;
        }

        // Gravity and falling
        if (falling) {
            dy += gravity;
            if (y >= 450) {  // Ground position
                y = 450;
                dy = 0;
                falling = false;
            }
        }

        // Update position
        x += dx;
        y += dy;

        // Boundaries to prevent Mario from going out of screen
        if (x < 0) x = 0;
        if (x > 750) x = 750;
    }

    // Draw player (Mario)
    public void draw(Graphics g) {
        g.setColor(Color.RED);
        g.fillRect(x, y, PLAYER_WIDTH, PLAYER_HEIGHT);
    }

    // Handle key press
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_LEFT) {
            left = true;
        }
        if (key == KeyEvent.VK_RIGHT) {
            right = true;
        }
        if (key == KeyEvent.VK_SPACE && !falling) {
            jumping = true;
        }
    }

    // Handle key release
    public void keyReleased(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_LEFT) {
            left = false;
        }
        if (key == KeyEvent.VK_RIGHT) {
            right = false;
        }
    }
}


