/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;


/**
 *
 * @author newit
 */


import javax.swing.JPanel;
import java.awt.*;
import java.awt.event.*;

public class GamePanel extends JPanel implements Runnable, KeyListener {

    // Panel dimensions
    private final int WIDTH = 800;
    private final int HEIGHT = 600;

    // Game Thread
    private Thread thread;
    private boolean running;
    
    // Player (Mario) object
    private Player mario;

    // Constructor
    public GamePanel() {
        this.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        this.setFocusable(true);
        this.addKeyListener(this);
        this.mario = new Player(100, HEIGHT - 150);
    }

    // Game initialization
    public void startGame() {
        running = true;
        thread = new Thread(this);
        thread.start();
    }

    @Override
    public void run() {
        // Main game loop
        while (running) {
            updateGame();
            repaint();
            try {
                Thread.sleep(16);  // ~60 FPS
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    // Game update logic
    private void updateGame() {
        mario.update();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Clear the screen
        g.setColor(Color.CYAN);
        g.fillRect(0, 0, WIDTH, HEIGHT);

        // Draw the ground
        g.setColor(Color.GREEN);
        g.fillRect(0, HEIGHT - 100, WIDTH, 100);

        // Draw Mario
        mario.draw(g);
    }

    // Key Events
    @Override
    public void keyPressed(KeyEvent e) {
        mario.keyPressed(e);
    }

    @Override
    public void keyReleased(KeyEvent e) {
        mario.keyReleased(e);
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }
}


